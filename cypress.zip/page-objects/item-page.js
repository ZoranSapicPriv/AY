class ItemPage {

    get getItemPageSizeDropdown () {
        return   cy.get('[data-testid="opener"]');
    }

    get getItemPageSizeOption1 () {
        return   cy.get('[data-testid="sizeOption_47796450_active"] > .sc-1rstdue-8')
    }

    get getItemPageAddToBasketBtn () {
        return   cy.get('[data-testid="addToBasketButton"]')
    }

}

export default new ItemPage();