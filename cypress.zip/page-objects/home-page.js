class HomePage {

    get getCookiePolicyOkBtn () {
        return   cy.get('#onetrust-accept-btn-handler');
    }

    get getDomainSelectorCloseBtn () {
        return   cy.get('[data-testid="modalDialogCloseIcon"]');
    }

    get getLanguageSelectorCloseBtn () {
        return   cy.get('[data-testid="languageSwitchCurrentLanguage"] > .sc-122ag38-1');
    }
    
    get getTopCategoriesContainerBekleidungBtn () {
        return   cy.get('[data-test-id="Header_navigation_list_item_Bekleidung"]')
    }
    

    
    open () {
        cy.visit('m.aboutyou.de');
        }  

}

export default new HomePage();
