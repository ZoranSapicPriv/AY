class CategoryPage {

    get getItemsGridProductImages () {
        return   cy.get('[data-testid="productImage"] > [data-testid="productImageView"]');
    }

}

export default new CategoryPage();