import homePage from "../../page-objects/home-page";
import categoryPage from "../../page-objects/category-page";
import itemPage from "../../page-objects/item-page";

describe('TC-100001 Unregistered customer buying 1 item', () => {

    beforeEach(() => {
        //Arrange
        homePage.open();
        //Act
        homePage.getCookiePolicyOkBtn.click();
        homePage.getDomainSelectorCloseBtn.click();
        homePage.getLanguageSelectorCloseBtn.click();
        //Assert
        cy.url().should("include","aboutyou.de");
      })

       it('TC 100001 - Given Unregistered customer visits the site When user browses to an item And selects the size And adds an item to a cart Then an item is added to a shopping cart', () => {
        //Arrange & Assert
        homePage.getTopCategoriesContainerBekleidungBtn.click();
        cy.url().should("include","bekleidung");

        //Arrange & Assert
        categoryPage.getItemsGridProductImages.first().click();
        cy.url().should("include","/p/");

        //Act
        itemPage.getItemPageSizeDropdown.click();
        itemPage.getItemPageSizeOption1.click();
        itemPage.getItemPageAddToBasketBtn.click();

        //Assert - error message should be displayed at the bottom of the page
        cy.get('.sc-jv18yo-3 > .ePNAqF').should('be.visible');
    });
    
});
